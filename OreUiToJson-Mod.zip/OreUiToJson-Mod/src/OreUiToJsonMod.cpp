#include <android/log.h>

#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <dlfcn.h>
#include <link.h>
#include <memory>

#include <pl/Mod.hpp>
#include <pl/memory/Hook.hpp>

// Ore UI to JSON UI
//
// The game decides per screen whether to show the Ore UI version or the old
// JSON UI version through one small function of its screen tech stack selector:
//
//     ui::TechStack ScreenTechStackSelector::getTechStackForScreen(
//         const std::string& screenName)
//
// Callers compare the result with 1 (Ore UI); any other value means JSON UI.
// It is called from 25 places (death, bed, main menu, play, edit world,
// settings, ...), so replacing it with "always JSON UI" switches every screen
// that has both versions, exactly like setting each per-screen developer
// override to JSON UI. Screens that exist only as Ore UI pages (for example
// the Marketplace) never ask this function and stay Ore UI.
//
// The address below is specific to ONE game build and is fingerprint-checked
// before anything is hooked. On any mismatch the mod hooks nothing.
//
// Minecraft Bedrock Android 1.26.62.1 (arm64-v8a)
// GNU Build ID: c60fa32908019eecae39ebfe7bac5755dc35cde2
// SHA-256: 2a915cf07bd165c5f939b02b36ee756878a63c4489f4971fb14e6e7bdf39216b

namespace oreuitojson {
namespace {

constexpr char kMinecraftLibrary[] = "libminecraftpe.so";
constexpr char kLogTag[] = "Ore UI to JSON UI";

constexpr std::uintptr_t kGetTechStackForScreenRva = 0x9AF921C;

constexpr std::array<std::uint8_t, 32> kGetTechStackForScreenFingerprint{
    0xFD, 0x7B, 0xBD, 0xA9, 0xF5, 0x0B, 0x00, 0xF9,
    0xF4, 0x4F, 0x02, 0xA9, 0xFD, 0x03, 0x00, 0x91,
    0xF4, 0x03, 0x01, 0xAA, 0xF5, 0x03, 0x00, 0xAA,
    0x11, 0x6C, 0x00, 0x94, 0x20, 0x01, 0x00, 0xB4,
};

// ui::TechStack values as the game's callers use them.
constexpr int kTechStackJsonUi = 0;

struct ModuleSearchState {
    std::uintptr_t base{0};
};

int moduleSearchCallback(
    dl_phdr_info* info,
    std::size_t,
    void* rawState
) noexcept {
    if (
        info == nullptr || info->dlpi_name == nullptr ||
        std::strstr(info->dlpi_name, kMinecraftLibrary) == nullptr
    ) {
        return 0;
    }
    static_cast<ModuleSearchState*>(rawState)->base =
        static_cast<std::uintptr_t>(info->dlpi_addr);
    return 1;
}

[[nodiscard]] std::uintptr_t minecraftModuleBase() noexcept {
    ModuleSearchState state{};
    dl_iterate_phdr(&moduleSearchCallback, &state);
    return state.base;
}

[[nodiscard]] bool belongsToMinecraft(std::uintptr_t address) noexcept {
    if (address == 0) {
        return false;
    }
    Dl_info info{};
    return dladdr(reinterpret_cast<void*>(address), &info) != 0 &&
        info.dli_fname != nullptr &&
        std::strstr(info.dli_fname, kMinecraftLibrary) != nullptr;
}

template <std::size_t N>
[[nodiscard]] std::uintptr_t resolveExactTarget(
    std::uintptr_t rva,
    const std::array<std::uint8_t, N>& fingerprint
) noexcept {
    const auto base = minecraftModuleBase();
    if (base == 0) {
        return 0;
    }
    const auto target = base + rva;
    if (!belongsToMinecraft(target)) {
        return 0;
    }
    return std::memcmp(
        reinterpret_cast<const void*>(target),
        fingerprint.data(),
        fingerprint.size()
    ) == 0 ? target : 0;
}

// Reads a libc++ std::string (arm64) without calling into the game. Returns
// false when the contents do not look like a short screen name.
[[nodiscard]] bool readScreenName(
    const void* rawString,
    char* out,
    std::size_t outSize
) noexcept {
    if (rawString == nullptr || outSize < 2) {
        return false;
    }
    const auto* bytes = static_cast<const std::uint8_t*>(rawString);
    const bool isLong = (bytes[0] & 1U) != 0;
    std::size_t size = 0;
    const char* data = nullptr;
    if (isLong) {
        std::memcpy(&size, bytes + 8, sizeof(size));
        std::memcpy(&data, bytes + 16, sizeof(data));
    } else {
        size = bytes[0] >> 1U;
        data = reinterpret_cast<const char*>(bytes + 1);
    }
    if (data == nullptr || size == 0 || size >= outSize || size > 96) {
        return false;
    }
    for (std::size_t i = 0; i < size; ++i) {
        const auto c = static_cast<unsigned char>(data[i]);
        if (c < 0x20 || c > 0x7E) {
            return false;
        }
        out[i] = static_cast<char>(c);
    }
    out[size] = '\0';
    return true;
}

std::atomic<int> gLoggedQueries{0};
constexpr int kMaxLoggedQueries = 40;

// ScreenTechStackSelector::getTechStackForScreen(this, const std::string&)
// Always answers "JSON UI".
int getTechStackForScreenDetour(
    void* /*selector*/,
    const void* screenName
) noexcept {
    if (gLoggedQueries.load(std::memory_order_relaxed) < kMaxLoggedQueries) {
        const int index = gLoggedQueries.fetch_add(1, std::memory_order_relaxed);
        if (index < kMaxLoggedQueries) {
            char name[128];
            if (readScreenName(screenName, name, sizeof(name))) {
                __android_log_print(
                    ANDROID_LOG_INFO,
                    kLogTag,
                    "screen '%s' -> JSON UI",
                    name
                );
            }
        }
    }
    return kTechStackJsonUi;
}

} // namespace

class OreUiToJsonMod final {
public:
    static OreUiToJsonMod& instance() noexcept {
        static OreUiToJsonMod mod;
        return mod;
    }

    bool load(pl::mod::ModContext& context) {
        context.logger().info("Ore UI to JSON UI loaded");
        return true;
    }

    bool enable(pl::mod::ModContext& context) {
        if (mHook) {
            return true;
        }

        const auto target = resolveExactTarget(
            kGetTechStackForScreenRva,
            kGetTechStackForScreenFingerprint
        );
        if (target == 0) {
            context.logger().warn(
                "Ore UI to JSON UI: this is not Minecraft 1.26.62.1 (fingerprint mismatch); nothing was hooked"
            );
            return true;
        }

        mHook = std::make_unique<pl::memory::HookHandle>(
            reinterpret_cast<void*>(target),
            reinterpret_cast<void*>(&getTechStackForScreenDetour),
            &mOriginal,
            pl::memory::HookPriority::Normal
        );
        if (!mHook || !mHook->installed()) {
            context.logger().warn(
                "Ore UI to JSON UI: hook failed; nothing was hooked"
            );
            removeHook();
            return true;
        }

        context.logger().info(
            "Ore UI to JSON UI active: screens with both versions now use JSON UI"
        );
        return true;
    }

    bool disable(pl::mod::ModContext& context) {
        removeHook();
        context.logger().info(
            "Ore UI to JSON UI disabled; restart the game to get Ore UI back everywhere"
        );
        return true;
    }

    bool unload(pl::mod::ModContext&) {
        removeHook();
        return true;
    }

private:
    OreUiToJsonMod() = default;

    void removeHook() noexcept {
        if (mHook) {
            mHook->reset();
            mHook.reset();
        }
        mOriginal = nullptr;
    }

private:
    std::unique_ptr<pl::memory::HookHandle> mHook;
    void* mOriginal{nullptr};
};

} // namespace oreuitojson

PL_REGISTER_MOD(
    oreuitojson::OreUiToJsonMod,
    oreuitojson::OreUiToJsonMod::instance()
)
