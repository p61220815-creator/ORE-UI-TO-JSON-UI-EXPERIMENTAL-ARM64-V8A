# Ore UI to JSON UI (experimental)

Native Levi Launcher mod for Minecraft Bedrock **1.26.62.1** (Google Play build, arm64-v8a).

The game picks, per screen, between the new Ore UI version and the old JSON UI version
through one small function of its "screen tech stack selector". This mod replaces that
function with one that always answers "JSON UI". It is the same thing the game's own
per-screen developer override (DEV_NEW_*_SCREEN_OVERRIDE = JSON UI) does, applied to every
screen at once.

## What changes

Screens that exist in both versions switch to the old JSON UI: main menu, pre-start,
Play, Settings, Edit World, Player Permissions, Send Invites, Start From Template,
Death, Bed, Safe Zone and the other screens the selector knows about.

Screens that only exist as Ore UI pages (for example the Marketplace) never ask the
selector and stay Ore UI. They keep working.

To go back, disable the pack in Levi Launcher and restart the game.

## Safety

- The target address is checked against 32 bytes of code first. On any other game build the
  mod hooks nothing and only writes a warning to the log.
- Only one function is replaced, and it returns a plain number, so nothing else is touched.
- The first 40 screen lookups are written to logcat under the tag `Ore UI to JSON UI`
  (for example `screen '/pre-start' -> JSON UI`). If something looks wrong, send me those lines.

The pack has not been run on a device by its author.

## Build in a fresh GitHub Codespace

1. github.com/codespaces -> **New codespace** -> pick any blank repo (or the "Blank" template).
2. Drag `OreUiToJson-Mod.zip` into the Explorer panel (left side).
3. In the Codespace terminal, run these lines:

```bash
unzip -o OreUiToJson-Mod.zip
cd OreUiToJson-Mod
PROJECT_DIR="$PWD"

sudo apt-get update
sudo apt-get install -y cmake ninja-build zip unzip wget openjdk-17-jre-headless

mkdir -p "$HOME/android-sdk/cmdline-tools"
cd "$HOME/android-sdk/cmdline-tools"
wget -q https://dl.google.com/android/repository/commandlinetools-linux-16111833_latest.zip -O cmdtools.zip \
  || wget -q https://dl.google.com/android/repository/commandlinetools-linux-15859902_latest.zip -O cmdtools.zip
unzip -q -o cmdtools.zip
rm -rf latest && mv cmdline-tools latest && rm cmdtools.zip

export ANDROID_HOME="$HOME/android-sdk"
yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses > /dev/null
"$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" "ndk;28.2.13676358"

cd "$PROJECT_DIR"
bash ./scripts/build.sh
```

4. The result is `dist/arm64-v8a/ore-ui-to-json-v0.2.0.levipack`. Right-click it in the
   Explorer -> **Download**, move it to your phone and import it in Levi Launcher.

The `wget` line tries the newest Linux "Command line tools only" zip first and falls back to the
previous one. If both fail, open developer.android.com/studio, scroll to "Command line tools
only", copy the Linux zip link and use it instead.

## How the address was found

`libminecraftpe.so` 1.26.62.1 (Build ID `c60fa32908019eecae39ebfe7bac5755dc35cde2`,
SHA-256 `2a915cf07bd165c5f939b02b36ee756878a63c4489f4971fb14e6e7bdf39216b`) is stripped.
The selector registers JS-facing wrappers named `getTechStackForScreen`,
`selectTechStackForScreen` and `getPreferredTechStackForScreen`; those led to the real
member function:

| Function | RVA |
|---|---|
| ScreenTechStackSelector::getTechStackForScreen(const std::string&) | `0x9AF921C` |

Its 25 callers compare the result with 1 (Ore UI); anything else takes the JSON UI path.
